#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include<QUdpSocket>
#include <QtGlobal>
#include<QTime>
#include<QDebug>
#include "qmath.h"
#include<sys/time.h>
class mythread:public QThread
{
    Q_OBJECT
public:

    explicit mythread(QObject *parent=0);
    ~mythread();

    int flag=1;
    int i=0;

    QUdpSocket *udpSocket;
    QByteArray datagram;

    QVector<double> mylist{0,0,0};//调零组
    double wl1=0;
    double wl2=0;
    double wl3=0;
    double res1 = 0;//暂存1
    double res2 = 0;//暂存2
    double res3 = 0;

    void deal();


    struct timeval tpstart,tpend;
    float timeuse;

protected:
    void run();

signals:
    //给主线程发消息
    void sendMsgToMain(double data1 , double data2 , double data3);

public slots:


    void Recv();
    void tiao();
    void StartOrder();
    void EndOrder();



    void dddflagStatus();
    void generateRandomNumber();

};

#endif // MYTHREAD_H
