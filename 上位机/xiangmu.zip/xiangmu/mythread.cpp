#include "mythread.h"

mythread::mythread(QObject *parent):QThread(parent)
{
    udpSocket = new QUdpSocket;
    udpSocket->bind(QHostAddress::Any,8000);
    connect(udpSocket,&QUdpSocket::readyRead,this,&mythread::Recv);
}

mythread::~mythread()
{
    udpSocket->close();
}

void mythread::deal()
{
    datagram.remove(0,4);//第一个数据
    int d=0;
    for(int i=0;i<2;i++)
    {
        int s=datagram[i];
        //qDebug()<<s;
        if(s<0)
        {
           s+=256;
        }
        d+=s*qPow(256,i);
    }

    wl1=d/1000.0+1520.0;
    //qDebug()<<wl1;
    datagram.remove(0,4);//第二个数据
    d=0;

    for(int i=0;i<2;i++)
    {
        int s=datagram[i];
        if(s<0)
        {
           s+=256;
        }
        d+=s*qPow(256,i);
    }
    wl2=d/1000.0+1520.0;

    datagram.remove(0,4);//第三个数据
    d=0;

    for(int i=0;i<2;i++)
    {
        int s=datagram[i];
        if(s<0)
        {
           s+=256;
        }
        d+=s*qPow(256,i);
    }
    wl3=d/1000.0+1520.0;


    if(flag==1)//调零
    {
        tiao();
        flag=0;
    }
    //调零计算
    res1=wl1-mylist[0];
    res2=wl2-mylist[1];
    res3=wl3-mylist[2];
    //将波长漂移量转换成力
    res1=res1/0.6081;
    res2=res2/0.6747;
    res3=res3/0.455;

    emit sendMsgToMain(res1 ,res2 , res3);//将数据发送到主线程

}

void mythread::run()
{

    qDebug()<<"udp线程开始";
    while (1) {
       sleep(1);
    }

}


void mythread::Recv()
{
    datagram.resize(udpSocket->pendingDatagramSize());//获取数据长度
    QHostAddress sender;//接收到的IP
    quint16 senderPort;//接收到的端口号
    //接收数据，参数1：数据，参数2：长度，参数3：目标IP，参数4:目标端口号
    udpSocket->readDatagram(datagram.data(),datagram.size(),&sender,&senderPort);
    //qDebug()<<datagram.size();
    deal();
}

void mythread::tiao()
{
    mylist[0] = wl1;
    mylist[1] = wl2;
    mylist[2] = wl3;
}

void mythread::StartOrder()
{
    QByteArray order_start = "010A55";
    QByteArray data_send = QByteArray::fromHex(order_start) ;
    udpSocket->writeDatagram(data_send,QHostAddress("192.168.0.119"),4010);
}

void mythread::EndOrder()
{
    QByteArray order_stop = "010A00";
    QByteArray data_send = QByteArray::fromHex(order_stop) ;
    udpSocket->writeDatagram(data_send,QHostAddress("192.168.0.119"),4010);
}


void mythread::dddflagStatus()
{
    flag=0;
}

void mythread::generateRandomNumber()
{
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        for(int i=0; i<10; i++)
        {
            int test =qrand()%10;
            qDebug()<<test;
        }
}

