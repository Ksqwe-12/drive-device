#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include "qmath.h"

//声明变量时会自动执行
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    global_port(new QSerialPort),
    global_port2(new QSerialPort)
{
    ui->setupUi(this);
    setWindowTitle("波长漂移量 ");
    init_system();
}

void MainWindow::init_system()
{

    thread = new mythread(this);//udp线程实例化
    thread->start();//开启udp线程
    timer = new QTimer(this);

    channel1->init();//初始化图表，在mychart.h/.cpp中
    //channel2->init();
    //channel3->init();

    chart_list.append(channel1);//加入容器
    //chart_list.append(channel2);
    //chart_list.append(channel3);

    ui->widget_1->setChart(channel1->chart);//将上述图表放入界面中
    //ui->widget_2->setChart(channel2->chart);
    //ui->widget_3->setChart(channel3->chart);

    ui->widget_1->show();//展示图表
    //ui->widget_2->show();
    //ui->widget_3->show();

    //串口1       设置停止位，校验，波特率等
    global_port->setStopBits(QSerialPort::OneStop);
    global_port->setParity(QSerialPort::NoParity);
    global_port->setDataBits(QSerialPort::Data8);
    global_port->setFlowControl(QSerialPort::NoFlowControl);

    //串口2
    global_port2->setStopBits(QSerialPort::OneStop);
    global_port2->setParity(QSerialPort::NoParity);
    global_port2->setDataBits(QSerialPort::Data8);
    global_port2->setFlowControl(QSerialPort::NoFlowControl);

    //udp解调仪接口
    //udpSocket = new QUdpSocket(this);
    //udpSocket->bind(QHostAddress::Any,8000);

    //udp接口接收数据并发送命令
    //connect(udpSocket,&QUdpSocket::readyRead,this,&MainWindow::data_receive);

    //设置串口  绑定按钮与槽
    connect(ui->openport,&QPushButton::clicked,this,&MainWindow::Setort);

    //断开连接
    connect(ui->disconnectport,&QPushButton::clicked,this,&MainWindow::Disconnect);

    //串口1和串口2设置接收函数
    connect(global_port,&QSerialPort::readyRead,this,&MainWindow::Receive);
    connect(global_port2,&QSerialPort::readyRead,this,&MainWindow::ReceiveB);


//    //线程间通信   在nythread.h/.cpp可见
    connect(this, &MainWindow::udpThreadstart_order, thread, &mythread::StartOrder);//开启
    connect(this, &MainWindow::udpThreadclose_order, thread, &mythread::EndOrder);//关闭
    connect(this, &MainWindow::udpTiao, thread, &mythread::tiao);//调零
    connect(thread, &mythread::sendMsgToMain , this, &MainWindow::cal_system);//绘图并打包命令发送

    connect(timer,&QTimer::timeout,[=](){
        //qDebug()<<"定时器:"<<times;
//        times++;
//        dSend();
    });


    //命令包赋初始值
    order->CurrentActual1="0.0";
    order->CurrentTarget1="0.0";
    order->CurrentActual2="0.0";
    order->CurrentTarget2="0.0";
    order->LineOrder="0";
    order->RoundOrder="0";
    order->isAuto = "0";
    //order->laF = "0";

}

void MainWindow::data_receive()//接收数据并更新
{

}

void MainWindow::deal()
{


}

void MainWindow::cal_system(double data1 , double data2 , double data3)//绘图并打包命令发送
{
    //保证每条曲线的点个数为500
    if(recpointF1.size()>500)
    {
        recpointF1.removeFirst();//超过500就丢弃第一个数据
    }
    if(recpointF2.size()>500)
    {
        recpointF2.removeFirst();
    }
    if(recpointF3.size()>500)
    {
        recpointF3.removeFirst();
    }

    //将数据放入曲线
    recpointF1.append(QPointF(num,data1));
    recpointF2.append(QPointF(num,data2));
    if(data3>-2)
    {
        read_data3 = data3;
    }

    recpointF3.append(QPointF(num,read_data3));
    //将数据放入储存用的容器
    recF1.append(data1);
    recF2.append(data2);
    recF3.append(read_data3);

    //用二号口发送总命令
    data1_buffer = data1;//时间测试用

    combineOrder(data1,data2,data3);//转换数据格式
    dSend();//打包命令发送

    //蓝  绿  黄
    //qDebug()<<num;
    //数据个数大于500之后调整横坐标的值
    if(num>chart_list[0]->xMax)
    {
        chart_list[0]->axisX->setRange(num-chart_list[0]->xMax,num);
    }

    chart_painter(recpointF1, recpointF2 , recpointF3);//绘制图表
    num++;
    //通信延迟测试
    gettimeofday(&tpend,NULL);
    timeuse=(1000000*(tpend.tv_sec-tpstart.tv_sec) + tpend.tv_usec-tpstart.tv_usec)/1000000.0;
    qDebug()<<"timewanzheng= "<<timeuse<<"s";
    gettimeofday(&tpstart,NULL);


}

void MainWindow::chart_painter(QVector<QPointF> rec_array1 , QVector<QPointF> rec_array2 , QVector<QPointF> rec_array3)//绘制图表
{
    chart_list[0]->series->replace(rec_array1);
    chart_list[0]->series2->replace(rec_array2);
    chart_list[0]->series3->replace(rec_array3);
}

void MainWindow::combineOrder(double x, double y,double z)//转换数据格式
{
    order->CurrentActual1 = QString::number(x,'f',3);
    order->CurrentActual2 = QString::number(y,'f',3);
    order->laF = QString::number(z,'f',3);
}



void MainWindow::Setort()//设置波特率与读取状态
{
    global_port->setBaudRate(115200);//波特率
    global_port->setPortName(ui->m_PortNameComboBox->currentText());//一号串口
    global_port->setReadBufferSize(1024);//缓冲区大小
    global_port->open(QIODevice::ReadWrite);//读写模式
    global_port->flush();//清空缓冲区
    qDebug()<<"ok1";
    global_port2->setBaudRate(115200);
    global_port2->setPortName(ui->m_PortNameComboBox_2->currentText());//二号串口
    global_port2->setReadBufferSize(1024);
    global_port2->open(QIODevice::ReadWrite);
    global_port2->flush();
    qDebug()<<"ok2";

    changeForce_flag=1;//开始运行
}



void MainWindow::Disconnect()
{
    global_port->clear();
    global_port->close();
    global_port2->clear();
    global_port2->close();
    st.clear();
    changeForce_flag=0;//停止运行
}

void MainWindow::Receive()
{
    num2++;
    plain_Date =  global_port->readAll(); //接收数据
    st+=plain_Date;
        int i=0;
        while((st[i]!='l')&&(st[i]!='\n'))//读左边摇杆数据
        {
            i++;
        }
            if((st[i]=='l')&&(st[i]!='\n'))
            {
                i++;
                if('0'<=st[i]&&st[i]<='2')
                {
                    order->LineOrder = st[i];
                    i++;
                }

            }
            if((st[i]=='r')&&(st[i]!='\n'))//读右边摇杆数据
            {
                i++;
                if('0'<=st[i]&&st[i]<='2')
                {
                    order->RoundOrder = st[i];
                    i++;
                }

            }
    st.clear();//清空缓存
    //dSend();
}

void MainWindow::ReceiveB()
{

}

void MainWindow::dSend()
{
    QString SendData;

    if(changeForce_flag==1)
    {
        changeForce();//防滑与急停保护
    }

    //自动控制
    //急停锁
    if(!STOP_flag)
    {
        if(autoGo!=0)
        {
        switch (autoGo) {
        case 1:
            order->LineOrder="2";//自动后退
            break;
        case 2:
            order->LineOrder="1";//自动前进
            break;
            }
        }
    }else {
        stopTarget();//发生碰撞，需要停止云顶并松开导管
    }
    //打包数据
    qDebug()<<"@c"+order->CurrentActual1+"c"+tiao_flag+"c"+order->CurrentTarget1+"f"+order->laF+"l"+order->LineOrder+"r"+order->RoundOrder+"a"+order->isAuto+"#";
    SendData="@c"+order->CurrentActual1+"c"+tiao_flag+"c"+order->CurrentTarget1+"f"+order->laF+"l"+order->LineOrder+"r"+order->RoundOrder+"a"+order->isAuto+"#";
    global_port2->write(SendData.toLatin1());//发送给下位机

}

void MainWindow::changeForce()
{

    double F_la_buf = order->laF.toDouble();
    double ccc = order->CurrentActual1.toDouble();

    if(F_la_buf>-2)
    {
        F_la = F_la_buf;
    }

    currentj1 = order->CurrentActual1.toDouble();

    if(F_la>STOP_value)
    {
        STOP();
    }

    if(!STOP_flag)
    {
        //qDebug()<<aaaa;
        //防滑
        if((F_la>aaaa)&&(F_la>-0.2))
        {

            if(aaaa==1.1)
            {
                tiao_flag = "1";
                order->CurrentTarget1 = "2";
                aaaa=0;
            }
            if((ccc<0.5)&&(fflag==1))
            {
                aaaa=3;
            }

            if(aaaa==0.8)
            {
                tiao_flag = "1";
                order->CurrentTarget1 = "1.5";
                aaaa=0;

            }
            if((ccc<0.5)&&(fflag==0))
            {
                aaaa=1.1;
                fflag=1;
            }

            ui->lineEdit->setText(order->CurrentTarget1);

        }else{
            tiao_flag = "0";
        }
    }

}


void MainWindow::STOP()//急停并锁定
{
    autoGo=0;
    STOP_flag = 1;
}

void MainWindow::stopTarget()//停止运动并松开导管
{
    order->LineOrder = "0";

//    if(order->CurrentTarget1!="0")
//    {
//        stop_buffer = order->CurrentTarget1;
//    }
    order->CurrentTarget1 = "0";
    //ui->lineEdit->setText(order->CurrentTarget1);
    tiao_flag = "1";
}

void MainWindow::on_pushButton_start_clicked()
{
//    QByteArray order_start = "010A55";
//    QByteArray data_send = QByteArray::fromHex(order_start) ;
//    udpSocket->writeDatagram(data_send,QHostAddress("192.168.0.119"),4010);
    emit udpThreadstart_order();
    st.clear();
}

void MainWindow::on_pushButton_stop_clicked()
{
//    QByteArray order_stop = "010A00";
//    QByteArray data_send = QByteArray::fromHex(order_stop) ;
//    udpSocket->writeDatagram(data_send,QHostAddress("192.168.0.119"),4010);
    emit udpThreadclose_order();
    Disconnect();
}

void MainWindow::on_pushButton_zero_clicked()
{
    emit udpTiao();
}

void MainWindow::on_setTarget_clicked()//设定夹持力
{
    QString str1=ui->lineEdit->text();//target设定值
    QString str2=ui->lineEdit_2->text();
    order->CurrentTarget1 = str1;
    order->CurrentTarget2 = str2;

}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
     dSend();
}

void MainWindow::on_pushButton_2_clicked()
{
    autoGo=2;
    order->isAuto="1";
    tiao_flag = "0";
}

void MainWindow::on_pushButton_3_clicked()
{
    autoGo=1;
    order->isAuto="1";
}

void MainWindow::on_pushButton_4_clicked()
{
    autoGo=0;
    order->isAuto="0";
    order->LineOrder="0";
}

void MainWindow::on_pushButton_5_clicked()
{
    STOP_flag = 0;
    tiao_flag = "1";
    order->CurrentTarget1 = "1.5";
    ui->lineEdit->setText(order->CurrentTarget1);
}


void MainWindow::on_pushButton_6_clicked()//储存数据
{

    QFileDialog fileDialog;
    QString fileName = fileDialog.getSaveFileName(this,tr("Open File"),"/mydata",tr("Text File(*.xls)"));//以excel表格的形式输出数据
    QFile file(fileName);
    bool ret = file.open(QIODevice::WriteOnly);
    if(ret==false)
    {
        return;
    }
    QTextStream out(&file);

    int time = recF1.length();

    for(int i = 0; i<time; i++)//分列输出
    {
        out<<recF1[i];
        out<<"\t";
        out<<recF2[i];
        out<<"\t";
        out<<recF3[i];
        out<<"\r\n";
    }
    file.close();

    recF1.clear();//清空
    recF2.clear();
    recF3.clear();

}
