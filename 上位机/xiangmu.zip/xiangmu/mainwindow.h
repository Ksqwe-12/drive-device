#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<QMainWindow>
#include<QDebug>
#include<QChartView>
#include<QPointF>
#include<QUdpSocket>
#include<QSerialPort>
#include <QComboBox>
#include"stdio.h"
#include"stdlib.h"
#include<QTimer>
#include"mychart.h"
#include"mythread.h"
#include<sys/time.h>


struct myorder{//命令包结构体，用于声明和储存命令变量
    QString CurrentActual1;//一号夹持器当前力
    QString CurrentActual2;
    QString CurrentTarget1;//一号夹持器设定力
    QString CurrentTarget2;
    QString LineOrder;//执行命令
    QString RoundOrder;//旋转命令
    QString isAuto;//是否自动运动
    QString laF;//拉力
};

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void init_system();//初始化函数，将准备好所有需要的变量与实例，绑定好所有的槽

    void data_receive();//弃用
    void deal();//弃用

    void cal_system(double data1 ,double data2,double data3);//用于接收mythread线程发过来的数据并绘制图像
    void chart_painter(QVector<QPointF> rec_array1 , QVector<QPointF> rec_array2 , QVector<QPointF> rec_array3);//画图子函数

    void combineOrder(double x,double y,double z);//转换数据格式

    void changeForce();//判断是否需要根据拉力改变夹持力
    void STOP();//急停函数1
    void stopTarget();//急停函数2

    mychart* channel1 = new mychart();//图表1
    //mychart* channel2 = new mychart();
    //mychart* channel3 = new mychart();

    mythread *thread;//udp线程,用于接收解调仪数据
    QTimer *timer;//弃用
    int times=0;//弃用

//    QVector<double> mylist{0,0};//调零组
//    double wl1=0;
//    double wl2=0;


    struct timeval tpstart,tpend;//用于计算通讯延迟
//    struct timeval tpstart1,tpend1;
    float timeuse1;//用于计算通讯延迟
    float timeuse;//用于计算通讯延迟


    QVector<mychart*> chart_list;//显示曲线的图表

    QByteArray datagram;//接收缓存区//弃用
    QVector<QPointF> recpointF1;//轴向夹持力线
    QVector<QPointF> recpointF2;//周向夹持力线
    QVector<QPointF> recpointF3;//拉力传感器线

    QVector<double> recF1;//用于储存轴向夹持力数据
    QVector<double> recF2;//用于储存周向夹持力数据
    QVector<double> recF3;//用于储存拉力数据

    int num = 0;//横坐标
    int num2 =0;//调试用
    int autoGo =0;//自动控制标志

    int dddd_flag = 1;//弃用

    double STOP_value = 1.8;//危险值
    double currentj1;//弃用
    double F_la;//拉力传感器数据

    int STOP_flag = 0;//急停锁定标志
    int changeForce_flag = 0;//开始运行标志

    double aaaa=0.8;//初始最大静摩擦力
    double dddd=0.8;//弃用
    double read_data3=0;//弃用

    double data1_buffer;//时间测试用

    int fflag=0;//防滑标志

    QString tiao_flag="0";//需要防滑标志
    QString stop_buffer;//弃用

//    double res1 = 0;//暂存1
//    double res2 = 0;//暂存2

    //串口
    QSerialPort *global_port;//接收手柄数据
    QByteArray plain_Date;//保存缓冲区数据
    QSerialPort *global_port2;//给下位机发送数据端口
    QString st;//合并接收到的数据

    void Setort();//设置串口配置
    void Disconnect();//断开连接，清空数据
    void Receive();//接收数据并处理
    void ReceiveB();//弃用
    void dSend();//打包数据并给下位机发送命令函数

    //命令包
    myorder *order = new(myorder);

signals:
    void udpThreadstart_order();//udp线程开始信号
    void udpThreadclose_order();//udp线程关闭信号
    void udpTiao();


//各种按钮的槽
private slots:

    void on_pushButton_start_clicked();

    void on_pushButton_stop_clicked();

    void on_pushButton_zero_clicked();

    void on_setTarget_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
