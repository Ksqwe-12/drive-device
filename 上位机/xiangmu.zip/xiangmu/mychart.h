#ifndef MYCHART_H
#define MYCHART_H
#include <QWidget>
#include<QtCharts>
#include<QChart>
#include<QChartView>
#include <QLineSeries>
#include<QValueAxis>
#include <QDateTimeAxis>
#include <QVector>
#include <QTimer>
#include <QRubberBand>
#include <QtMath>
class mychart : public QChart
{
public:
    mychart();
    ~mychart();

    void init();


     QChart *chart;
     QLineSeries *series;
     QLineSeries *series2;
     QLineSeries *series3;

     QValueAxis *axisX;
     QValueAxis *axisY;


     bool isClicking;
     int xOld ;
     int yOld ;

     int xMax=500;
     int xMin=0;
     int yMax=5;
     int yMin=0;


};

#endif // MYCHART_H
